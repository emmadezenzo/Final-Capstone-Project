//
//  BubbleHomeViewController.swift
//  Photo App
//
//  Created by Spence on 7/30/18.
//  Copyright © 2018 Girls How Code. All rights reserved.
//

import UIKit
//trash pieces
var glassBottleHide=false
var waterBottleHide=false
var plasticBagHide=false
var cokeBottleHide=false
var sodaCanHide=false


class BubbleHomeViewController: UIViewController {
var photoWasTaken=false
    var TrashTracker = 0
    @IBOutlet weak var bubbles: UIImageView!
    
    //outlets and actions
    
    @IBOutlet weak var SodaCan: UIImageView!
    @IBOutlet weak var PlasticBag: UIImageView!
    @IBOutlet weak var CokeBottle: UIImageView!
    @IBOutlet weak var WaterBottle: UIImageView!
    @IBOutlet weak var GlassBottle: UIImageView!
    
    func stopAnimating(){
        
    }
    //code that makes sodacan go away
    override func viewDidLoad() {
        super.viewDidLoad()
//        GoodJob.isHidden=true
    }
    

    //code that makes pieces of trash disapper
    override func viewWillAppear(_ animated: Bool) {
        
        if (sodaCanHide)==true{
            SodaCan.isHidden=true
    }
        else {
           SodaCan.isHidden=false
        }
        
        if (cokeBottleHide)==true{
            CokeBottle.isHidden=true
        }
        else {
            CokeBottle.isHidden=false
        }
        
        if (plasticBagHide==true){
            PlasticBag.isHidden=true
        }
        else {PlasticBag.isHidden=false}
        
        if (waterBottleHide==true){
            WaterBottle.isHidden=true
        }
        else {WaterBottle.isHidden=false}
        
        if (glassBottleHide==true){
            GlassBottle.isHidden=true
//            GoodJob.isHidden=false
        }
        else {GlassBottle.isHidden=false}
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
        }



