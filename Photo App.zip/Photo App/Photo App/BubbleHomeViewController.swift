//
//  BubbleHomeViewController.swift
//  Photo App
//
//  Created by Spence on 7/30/18.
//  Copyright © 2018 Girls How Code. All rights reserved.
//

import UIKit

class BubbleHomeViewController: UIViewController {
var photoWasTaken=false 
    @IBOutlet weak var bubbles: UIImageView!
    @IBOutlet weak var SodaCan: UIImageView!
    
    
    func stopAnimating(){
        
    }
    //code that makes Sodacan go away 
    override func viewDidLoad() {
        super.viewDidLoad()
        if photoWasTaken{
            SodaCan.image=UIImage(named:"")
        }

        // Do any additional setup after loading the view.
    }

    private func setUpImageViewAnimation(){
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //code to make coke bottle  dissappear
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        //this code is the segue from the camera to BubbleHomeViewController
        if segue.destination is BubbleHomeViewController
        {
            let vc = segue.destination as? BubbleHomeViewController
            vc?.photoWasTaken = true
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
